@extends('layouts.bar')
<style>
    input[type=radio] {
        border: 0px;
        width: 100%;
        height: 2em;
    }

    .styled {
        border: 0;
        line-height: 2.5;
        padding: 0 20px;
        font-size: 1rem;
        text-align: center;
        color: #fff;
        text-shadow: 1px 1px 1px #000;
        border-radius: 10px;
        background-color: rgba(220, 0, 0, 1);
        background-image: linear-gradient(to top left,
                rgba(0, 0, 0, .2),
                rgba(0, 0, 0, .2) 30%,
                rgba(0, 0, 0, 0));
        box-shadow: inset 2px 2px 3px rgba(255, 255, 255, .6),
            inset -2px -2px 3px rgba(0, 0, 0, .6);
    }

    body {
        margin-top: 20px;
        background: #f5f5f5;

    }

    .categories-card.card {
        border: none;
        box-shadow: none
    }

    .categories-card .card-img-overlay {
        display: flex
    }

    .categories-card .card-img-overlay>* {
        flex: 1
    }

    .categories-card h3 {
        margin-bottom: 5px;
        font-size: 14px;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 1px
    }

    .categories-card .bg-white-opacity {
        text-align: center;
        padding: 20px 20px 18px 20px
    }

    .card {
        position: relative;
        display: -ms-flexbox;
        display: flex;
        -ms-flex-direction: column;
        flex-direction: column;
        min-width: 0;
        word-wrap: break-word;
        background-color: #fff;
        background-clip: border-box;
        border: 1px solid rgba(0, 0, 0, .125);
        border-radius: .25rem;
    }

    .bg-white-opacity {
        background-color: rgba(255, 255, 255, 0.85);
    }

    .categories-02 {
        padding: 0;
        margin: 0;
    }

    .categories-02 li {
        display: inline-block;
        margin-right: 20px;
        font-size: 14px;
        font-weight: 600;
        opacity: .8;
        vertical-align: middle;
    }

    .categories-02 li a {
        color: rgba(0, 0, 0, 0.85);
    }

    a,
    a:active,
    a:focus {
        color: #5e6973;
        text-decoration: none;
        transition-timing-function: ease-in-out;
        -ms-transition-timing-function: ease-in-out;
        -moz-transition-timing-function: ease-in-out;
        -webkit-transition-timing-function: ease-in-out;
        -o-transition-timing-function: ease-in-out;
        transition-duration: .2s;
        -ms-transition-duration: .2s;
        -moz-transition-duration: .2s;
        -webkit-transition-duration: .2s;
        -o-transition-duration: .2s;
    }

  

    img {
        max-width: 100%;
        height: auto;
    }


  
</style>

<body>

    <a class="btn btn-success" href="home"> Back</a>
    <div class="container">
        <div class="section-header text-center text-white">
            <br>
            <br>

            <div class="section-header text-center">
                <h2 class="">Choisir mon offre ADSL</h2>
            </div>
        
            <div class="container">
                <form method="get" class="needs-validation" action='{{ route('commandes.create') }}'>
                    <div class="row">
                        @foreach ($offres as $offre)
                            <div class="col-sm-4 p-2">
                                <img src="{{ Storage::url($offre->image) }}" alt="" />
                                <div class="card-body">
                                    <h5 class="card-title "> {{ $offre->title }}</h5>
                                    <p class="card-text"> {{ $offre->description }}</p>
                                    <input type="radio" class="option-input radio " name="offre" value="{{ $offre->id }}" required />
                                </div>
                            </div>
                        @endforeach
                    </div>
                    <div class=" text-center">
                        <button class="favorite styled" type="submit">Suivant</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    </div>
    </div>

    <div class="footer wow fadeIn" data-wow-delay="0.3s">
        <div class="container">
           
        </div>
    </div>
    <!-- Footer End -->

    <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/isotope/isotope.pkgd.min.js"></script>
    <script src="lib/lightbox/js/lightbox.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/counterup/counterup.min.js"></script>
    <script src="lib/slick/slick.min.js"></script>

    <!-- Contact Javascript File -->
    <script src="mail/jqBootstrapValidation.min.js"></script>
    <script src="mail/contact.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>
