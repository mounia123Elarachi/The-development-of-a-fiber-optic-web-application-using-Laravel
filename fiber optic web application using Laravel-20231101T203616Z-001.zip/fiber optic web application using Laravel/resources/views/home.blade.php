@extends('layouts.bar')
@extends('layouts.app')


@section('content')
    <div class="contact wow fadeInUp">
        <style>
            .bg {
                background: #fdbe33;
            }

            .styled {
                border: 0;
                line-height: 2.5;
                padding: 0 20px;
                font-size: 1rem;
                text-align: center;
                color: #fff;
                text-shadow: 1px 1px 1px #000;
                border-radius: 10px;
                background-color: rgba(220, 0, 0, 1);
                background-image: linear-gradient(to top left,
                        rgba(0, 0, 0, .2),
                        rgba(0, 0, 0, .2) 30%,
                        rgba(0, 0, 0, 0));
                box-shadow: inset 2px 2px 3px rgba(255, 255, 255, .6),
                    inset -2px -2px 3px rgba(0, 0, 0, .6);
            }

            .styled:hover {
                background-color: rgba(255, 0, 0, 1);
            }

            .styled:active {
                box-shadow: inset -2px -2px 3px rgba(255, 255, 255, .6),
                    inset 2px 2px 3px rgba(0, 0, 0, .6);
            }

            .by {
                color: red;
                font-style: italic;
                font-size: 29px;
            }

            .ny {
                color: black;
                font-style: Arial;
                font-size: 19px;
            }
        </style>

        <body>
            <div class="top-bar">
                <div class="container-fluid">
                    <div class="row align-items-center">
                        <div class="col-lg-4 col-md-12">
                            <div class="logo">
                                <!-- <a href="index.html"> -->


                                <div class="pull-left">
                                    <a class="btn btn-primary" href="{{ route('clients.index') }}"> Back</a>
                                </div>
                                </a>
                            </div>
                        </div>



                        <style>
                            img.displayed {
                                display: block;
                                margin-left: auto;
                                margin-right: auto
                            }

                            .bg {
                                background: #fdbe33;
                            }
                        </style>
                        <!-- About Start -->
                        <div class="container">
                            <div class="about wow fadeInUp" data-wow-delay="0.1s">
                                <div class="container">
                                    <div class="row align-items-center">
                                        <div class="col-lg-5 col-md-6">
                                            <div class="about-img">
                                                <img class="displayed" src="{{ Storage::url($client->image2) }}"
                                                    alt="" />
                                            </div>
                                        </div>
                                        <div class="col-lg-7 col-md-6">
                                            <div class="section-header text-left">

                                                <h2> {{ $client->title }}</h2>
                                            </div>
                                            <div class="about-text">
                                                <p> {{ $client->description }} </p>
                                                <p>
                                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus nec
                                                    pretium mi. Curabitur facilisis ornare velit non vulputate. Aliquam
                                                    metus
                                                    tortor, auctor id gravida condimentum, viverra quis sem. Curabitur non
                                                    nisl
                                                    nec nisi scelerisque maximus. Aenean consectetur convallis porttitor.
                                                    Aliquam interdum at lacus non blandit.
                                                </p>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- About End -->
                            <div class="container">
                                <h2>{{ $client->name1 }}</h2>
                                <p>The .table class adds basic styling (light padding and only horizontal dividers) to a
                                    table:
                                </p>
                                <table class="table table-striped table-dark">
                                    <thead>
                                        <tr>
                                            <th class="bg" scope="col">Débits</th>
                                            <th scope="col">4M</th>
                                            <th scope="col">8M</th>
                                            <th scope="col">12M</th>
                                            <th scope="col">20M</th>

                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <th class="bg" scope="row">Tarifs</th>
                                            <td>{{ $client->period1 }}</td>
                                            <td>{{ $client->period2 }}</td>
                                            <td>{{ $client->period3 }}</td>
                                            <td>{{ $client->period4 }}</td>

                                        </tr>


                                    </tbody>
                                </table>
                                <div class="container">
                                    <h2>{{ $client->name2 }}</h2>
                                    <p>The .table class adds basic styling (light padding and only horizontal dividers) to a
                                        table:</p>
                                    <table class="table table-striped table-dark">
                                        <thead>
                                            <tr>
                                                <th class="bg" scope="col">Débits</th>
                                                <th scope="col">4M</th>
                                                <th scope="col">8M</th>
                                                <th scope="col">12M</th>
                                                <th scope="col">20M</th>

                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <th class="bg" scope="row">Tarifs</th>
                                                <td>{{ $client->period5 }}</td>
                                                <td>{{ $client->period6 }}</td>
                                                <td>{{ $client->period7 }}</td>
                                                <td>{{ $client->period8 }}</td>

                                            </tr>


                                        </tbody>
                                    </table>
                                    <h3 class="text-center">{{ $client->body }}</H3>
                                    <img class="displayed" src="{{ Storage::url($client->image1) }}" alt="" />
                                    <!-- Fact End -->
                                    <!-- Contact Start -->
                                    <div class="team">

                                        <div class="container">
                                            <div class="section-header text-center">
                                                <h2>Les forfaits Max d'internet</h2>
                                            </div>
                                            <div class="row">
                                                @foreach ($posts as $post)
                                                    <div class="team-item">

                                                        <img src="{{ Storage::url($post->image) }}" alt="" />

                                                        <div class="team-text">

                                                            {{ $post->title }}
                                                            {{ $post->description }}
                                                        </div>

                                                    </div>
                                            </div>
                                            @endforeach
                                        </div>
                                    </div>
                                </div>
                                <script src="https://smtpjs.com/v3/smtp.js"></script>

                                <script src="js/app.js"></script>
                                <!-- Contact End -->


                                <!-- Footer Start -->
                                <div class="footer wow fadeIn" data-wow-delay="0.3s">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-md-6 col-lg-3">
                                                <div class="footer-contact">
                                                    <h2>Office Contact</h2>
                                                    <p><i class="fa fa-map-marker-alt"></i>123 Street, New York, USA</p>
                                                    <p><i class="fa fa-phone-alt"></i>+012 345 67890</p>
                                                    <p><i class="fa fa-envelope"></i>info@example.com</p>
                                                    <div class="footer-social">
                                                        <a href=""><i class="fab fa-twitter"></i></a>
                                                        <a href=""><i class="fab fa-facebook-f"></i></a>
                                                        <a href=""><i class="fab fa-youtube"></i></a>
                                                        <a href=""><i class="fab fa-instagram"></i></a>
                                                        <a href=""><i class="fab fa-linkedin-in"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6 col-lg-3">
                                                <div class="footer-link">
                                                    <h2>Services Areas</h2>
                                                    <a href="">Building Construction</a>
                                                    <a href="">House Renovation</a>
                                                    <a href="">Architecture Design</a>
                                                    <a href="">Interior Design</a>
                                                    <a href="">Painting</a>
                                                </div>
                                            </div>
                                            <div class="col-md-6 col-lg-3">
                                                <div class="footer-link">
                                                    <h2>Useful Pages</h2>
                                                    <a href="">About Us</a>
                                                    <a href="">Contact Us</a>
                                                    <a href="">Our Team</a>
                                                    <a href="">Projects</a>
                                                    <a href="">Testimonial</a>
                                                </div>
                                            </div>
                                            <div class="col-md-6 col-lg-3">
                                                <div class="newsletter">
                                                    <h2>Newsletter</h2>
                                                    <p>
                                                        Lorem ipsum dolor sit amet elit. Phasellus nec pretium mi. Curabitur
                                                        facilisis ornare velit non vulpu
                                                    </p>
                                                    <div class="form">
                                                        <input class="form-control" placeholder="Email here">
                                                        <button class="btn">Submit</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="container footer-menu">
                                        <div class="f-menu">
                                            <a href="">Terms of use</a>
                                            <a href="">Privacy policy</a>
                                            <a href="">Cookies</a>
                                            <a href="">Help</a>
                                            <a href="">FQAs</a>
                                        </div>
                                    </div>
                                    <div class="container copyright">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <p>&copy; <a href="#">Your Site Name</a>, All Right Reserved.</p>
                                            </div>
                                            <div class="col-md-6">
                                                <p>Designed By <a href="https://htmlcodex.com">HTML Codex</a></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- Footer End -->

                                <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>
                            </div>

                            <!-- JavaScript Libraries -->
                            <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
                            <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
                            <script src="lib/easing/easing.min.js"></script>
                            <script src="lib/wow/wow.min.js"></script>
                            <script src="lib/owlcarousel/owl.carousel.min.js"></script>
                            <script src="lib/isotope/isotope.pkgd.min.js"></script>
                            <script src="lib/lightbox/js/lightbox.min.js"></script>
                            <script src="lib/waypoints/waypoints.min.js"></script>
                            <script src="lib/counterup/counterup.min.js"></script>
                            <script src="lib/slick/slick.min.js"></script>

                            <!-- Contact Javascript File -->
                            <script src="mail/jqBootstrapValidation.min.js"></script>
                            <script src="mail/contact.js"></script>

                            <!-- Template Javascript -->
                            <script src="js/main.js"></script>
                        @endsection
                        <script src="js/main.js"></script>
    </body>

    </html>
