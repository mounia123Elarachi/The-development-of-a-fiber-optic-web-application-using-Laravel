<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CommandeController;
use App\Http\Controllers\HomeAgentController;
use App\Http\Controllers\HomeAdminController;
use App\Http\Controllers\OffreController;
use App\Http\Controllers\postsController;
use App\Http\Controllers\ClientController;
use App\Http\Controllers\navbarController;






/* |-------------------------------------------------------------------------- | Web Routes |-------------------------------------------------------------------------- | | Here is where you can register web routes for your application. These | routes are loaded by the RouteServiceProvider within a group which | contains the "web" middleware group. Now create something great! | */

Route::get('/', function () {

    return view('welcome');
});

Auth::routes();
Route::get('/posts.index1', [App\Http\Controllers\postsController::class , 'index1'])->name('home');
Route::resource('posts', postsController::class);
Route::get('/navbar.forfais', [App\Http\Controllers\navbarController::class , 'index'])->name('navbar');
Route::get('/navbar.service', [App\Http\Controllers\navbarController::class , 'index1'])->name('navbar');
Route::get('/navbar.about', [App\Http\Controllers\navbarController::class , 'index2'])->name('navbar');
Route::get('/navbar.Home', [App\Http\Controllers\navbarController::class , 'index3'])->name('navbar');
Route::get('/navbar.contact', [App\Http\Controllers\navbarController::class , 'index4'])->name('navbar');



Route::get('/contact', [App\Http\Controllers\ContactController::class , 'index'])->name('contact');
Route::get('/contact', [App\Http\Controllers\OffreController::class , 'index1'])->name('contact');

Route::get('/commandes.offress', [App\Http\Controllers\CommandeController::class , 'show1'])->name('offres');






Route::get('/AdminHome', [App\Http\Controllers\HomeAdminController::class , 'index'])->name('AdminHome');



// AGENT COMMERCIAL

Route::get('/HomeAgentcomm', [App\Http\Controllers\CommandeController::class , 'index'])->name('HomeAgentcomm');
Route::get('/commandes.create', [App\Http\Controllers\CommandeController::class , 'create'])->name('commandes.create');
Route::get('/HomeAgentcomm', [App\Http\Controllers\HomeAgentcomController::class , 'show'])->name('HomeAgentcomm');
// // commandes
Route::resource('commandes', CommandeController::class);
Route::get('/commandes.index1', [App\Http\Controllers\CommandeController::class , 'index1'])->name('commandes.index1');
Route::get('/HomeAgentcomm', [App\Http\Controllers\CommandeController::class , 'update'])->name('HomeAgentcomm');
Route::get('/HomeAgentcomm', [App\Http\Controllers\CommandeController::class , 'destroy'])->name('HomeAgentcomm');

// offres

Route::resource('offres', OffreController::class);
Route::get('/offres.index', [App\Http\Controllers\OffreController::class, 'index'])->name('offres.index');
Route::get('/offres.create', [App\Http\Controllers\OffreController::class, 'create'])->name('offres.create');
Route::get('/offres.edit', [App\Http\Controllers\OffreController::class, 'edit'])->name('offres.edit');
Route::get('/offres.update', [App\Http\Controllers\OffreController::class, 'update'])->name('offres.update');



// Route::get('/home', [emailController::class, 'index']);
// Route::post('/home', [emailController::class, 'save'])->name('email.store');


// All Normal Users Routes List

Route::middleware(['auth', 'user-access:user'])->group(function () {

    Route::get('/home', [postsController::class , 'index1'])->name('home');
});


/*------------------------------------------ -------------------------------------------- All Admin Routes List -------------------------------------------- --------------------------------------------*/
Route::middleware(['auth', 'user-access:admin'])->group(function () {

    Route::get('/AdminHome', [HomeAdminController::class , 'index'])->name('AdminHome');
});


/*------------------------------------------ -------------------------------------------- All Admin Routes List -------------------------------------------- --------------------------------------------*/
Route::middleware(['auth', 'user-access:Agentcomm'])->group(function () {

    Route::get('/commandes.index', [CommandeController::class , 'index'])->name('commandes.index');
});

// ::::::::::::::::::::::::::::::: tableau

Route::resource('clients', ClientController::class);
Route::get('/listClient', [CommandeController::class , 'showme'])->name('listClient');
Route::get('/showprofil', [ClientController::class , 'show1'])->name('showprofil');
